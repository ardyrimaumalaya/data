---
name: "\U0001F4FA Channel Request"
about: Request to add a channel to the playlist
title: 'Add: xxx'
labels: channel request
assignees: ''

---

<!-- Please fill out the information in this issue template so that we can
efficiently process your request -->

<!-- IMPORTANT: An issue may contain a request for only one channel, otherwise it will be closed -->

**Channel Name:** xxx
**Country:** xxx
**Language:** xxx
**External Link (optional):** xxx
**Notes (optional):** xxx
